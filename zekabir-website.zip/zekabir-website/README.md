# Zeka BIR Tech Solutions — website

Production-ready static site. No build step, no dependencies, no framework.
Upload the folder and it runs.

```
index.html                       Full site (HTML + CSS + JS in one file)
404.html                         Branded not-found page
assets/mark.png                  Logo mark, transparent, 1024px
assets/wordmark-line-dark.png    "ZEKA BIR" for dark backgrounds (header)
assets/wordmark-dark.png         Two-line lockup for dark backgrounds (footer)
assets/wordmark-light.png        Two-line lockup for light backgrounds
assets/logo-lockup-light.png     Full stacked lockup, light backgrounds
assets/logo-lockup-dark.png      Full stacked lockup, dark backgrounds
favicon.png / apple-touch-icon.png
og-image.png                     1200×630 social share image
robots.txt · sitemap.xml
netlify.toml · vercel.json       Security headers, caching, 404 routing
```

All logo files were extracted from the artwork you supplied, cleaned up
(background removed, edges re-rendered so they stay sharp at any size) and
recoloured only where a dark background required it. The mark itself is
unchanged.

---

## 1. Before you go live — five things to change

All of these are in `index.html`. Search for the text and replace it.

| Find | Replace with | Where |
|---|---|---|
| `connect@zekabir.com` | Real email (appears 4×) | Contact, footer, form script |
| `+91 00000 00000` and `tel:+910000000000` | Real phone | Contact, footer |
| `Zeka BIR Tech Solutions Pvt. Ltd.<br />India` | Full registered office address | Contact block |
| `https://www.zekabir.com/` | Live domain (appears in canonical, OG tags, JSON-LD) | `<head>` |
| `var ENDPOINT = "";` | Your form endpoint — see below | Bottom of `index.html` |

Also update the domain in `sitemap.xml` and `robots.txt`.

## 2. Making the contact form actually deliver

Right now the form validates input and, with `ENDPOINT` empty, opens the visitor's
email client with everything pre-filled. That works, but it loses enquiries from
anyone without a mail client configured. Pick one of these instead:

**Formspree (fastest — 2 minutes)**
1. Create a form at formspree.io, copy the endpoint URL.
2. In `index.html`, set `var ENDPOINT = "https://formspree.io/f/xxxxxxx";`

**Netlify Forms (free if hosting on Netlify)**
1. Add `netlify` and `name="contact"` to the `<form>` tag:
   `<form id="cform" name="contact" method="POST" data-netlify="true" novalidate>`
2. Add a hidden input: `<input type="hidden" name="form-name" value="contact" />`
3. Set `var ENDPOINT = "/";`

**Your own backend** — POST JSON to any URL that returns 2xx. The payload keys are
`name, company, role, email, phone, interest, message`.

The `_gotcha` field is a honeypot: bots fill it, humans don't, and the script
silently drops those submissions.

## 3. Deploy

**Netlify (drag and drop)**
Go to app.netlify.com/drop and drag the whole folder in. Live in seconds.
Then Site settings → Domain management → add `zekabir.com`.

**Vercel**
```bash
npm i -g vercel
cd zekabir
vercel --prod
```

**GitHub Pages**
```bash
git init && git add . && git commit -m "Zeka BIR website"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```
Then Settings → Pages → Source: `main` / root.
(GitHub Pages ignores `netlify.toml` and `vercel.json` — harmless.)

**cPanel / traditional hosting**
Upload all files into `public_html/` via File Manager or FTP. Nothing else needed.

**Cloudflare Pages** — connect the repo, leave the build command blank,
output directory `/`.

## 4. DNS

Point the domain at your host, then force HTTPS (every platform above issues a
free certificate automatically). Set the `www` vs non-`www` redirect in one
direction only and keep the canonical tag in `index.html` matching it.

## 5. Analytics (optional)

Paste before `</head>` in `index.html`:

```html
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date()); gtag('config', 'G-XXXXXXX');
</script>
```

Plausible or Fathom are lighter alternatives if you'd rather not run GA.

---

## Design notes (for whoever edits this next)

The palette and structure come directly from the logo, so keep them tied together:

| Token | Value | Where it comes from |
|---|---|---|
| `--ink` / `--navy` | `#050F1F` / `#0C1B36` | The disc |
| `--brass` / `--brass-hi` | `#C2963E` / `#EBD5A0` | The arc |
| `--teal` | `#0E8163` | The dot |
| `--parch` | `#F3F1EC` | Warm relief between the dark sections |

Three recurring dot colours map to the three pillars in the logo lockup —
BI & Analytics, Financing, Technology. Section eyebrows use them.

The page alternates dark and parchment sections so it reads with rhythm rather
than as one long slab. Icons are Lucide (ISC licence), inlined as SVG so there
is no icon-font request. A thin gradient bar under the header tracks scroll
position.

Type: **Archivo** (display, chosen to sit close to the logo wordmark),
**Inter** (body), **IBM Plex Mono** (labels and figures), **Newsreader italic**
for the two pull-quotes only. All from Google Fonts. If the site must work offline or in a
locked-down network, self-host them and swap the `<link>` for local `@font-face`
rules — the CSS variables `--display`, `--body`, `--mono` are the only places to change.

Numbering appears in exactly one place — the four Approach stages — because that
is the only content on the page where the order genuinely matters.

Accessibility and performance are already handled: skip link, visible keyboard
focus, `prefers-reduced-motion` respected, semantic landmarks, ARIA on the mobile
menu, no external JS, no images except the OG card. Expect a near-perfect
Lighthouse score once the fonts are cached.

## Editing common things

- **Add a service:** copy any `<article class="svc rv">` block in the Services section.
- **Add a sector:** copy a `<div class="sec">` block in the Investments section.
- **Change a stat:** the four `.mt` blocks under the hero (edit `data-count` and `data-suffix`).
- **Change nav:** edit both `<nav class="nav">` (desktop) and `#drawer` (mobile).


## A note on client names

No client is named anywhere on the site. The Investments section says mandates
run across NBFCs, FinTech platforms, MSME lenders and technology businesses, and
that references are shared on request. If you later get written consent from a
client, the cleanest place to add a logo wall is directly below that paragraph.
